# coding: utf-8

from __future__ import print_function, absolute_import, division, unicode_literals


class Data(object):
    def __init__(self, args, config):
        self._args = args
        self._config = config
