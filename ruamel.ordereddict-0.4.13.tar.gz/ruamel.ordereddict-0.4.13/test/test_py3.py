# coding: utf-8

import sys
import pytest

from ruamel.ordereddict import ordereddict, sorteddict

assert sys.version_info >= (3, )
