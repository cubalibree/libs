# -*- coding: utf-8 -*-
"""
    sphinx.environment.adapters
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~

    Sphinx environment adapters

    :copyright: Copyright 2007-2018 by the Sphinx team, see AUTHORS.
    :license: BSD, see LICENSE for details.
"""
