System information
------------------

This information is provided by directive::

  .. packages:platform::

It list some platform information.

.. packages:platform::

