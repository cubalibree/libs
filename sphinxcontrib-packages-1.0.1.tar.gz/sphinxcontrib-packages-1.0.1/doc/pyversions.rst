Available python versions
-------------------------

This information is provided by directive::

  .. packages:pyversions::

It lists the available python versions.

.. packages:pyversions::

