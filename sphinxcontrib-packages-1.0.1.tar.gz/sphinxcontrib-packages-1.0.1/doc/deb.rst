Installed `.deb` packages
=========================

This information is provided by the directive::

  .. packages:deb::

It lists installed deb packages, sorted by section. It uses the `dpkg-query` binary.

.. packages:deb::
