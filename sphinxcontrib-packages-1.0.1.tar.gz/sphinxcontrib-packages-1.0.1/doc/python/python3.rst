Installed python3 packages
==========================

This information is provided by the directive::

  .. packages:python3::

which is a shortcut to::

  .. packages:python::
     :bin: python3

It lists available python3 packgaes.

.. packages:python3::
