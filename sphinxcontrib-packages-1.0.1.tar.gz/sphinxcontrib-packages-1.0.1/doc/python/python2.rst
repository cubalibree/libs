Installed python2 packages
==========================

This information is provided by the directive::

  .. packages:python2::

which is a shortcut to::

  .. packages:python::
     :bin: python2

It lists available python2 packgaes.

.. packages:python2::
